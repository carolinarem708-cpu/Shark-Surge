# Shark Surge

A mobile-friendly browser arcade game made with plain HTML, CSS, and JavaScript. No build tools, no external assets, and no dependencies.

## Gameplay

You play as a shark. Eat fish smaller than you to score points and grow. Larger fish and jellyfish damage you until you are big enough or have the right ability.

### Abilities

- **Level 1: Bite** — eat small fish.
- **Level 2: Dash** — press Space or the Dash button for a burst of speed.
- **Level 3: Current Pull** — edible fish are gently pulled toward you.
- **Level 4: Iron Hide** — chance to block damage and extra health.
- **Level 5+: Frenzy Dash** — dashing can overpower tougher enemies.

## Controls

- Desktop: Arrow keys or WASD to move; Space to dash.
- Mobile: Tap/drag in the play area or use the on-screen controls.

## Deploy to Netlify

### Option 1: Drag-and-drop

1. Unzip this folder.
2. Go to Netlify.
3. Drag the entire `shark-arcade-game` folder into Netlify's deploy area.
4. Netlify will serve `index.html` automatically.

### Option 2: GitHub + Netlify

1. Create a new GitHub repository.
2. Upload `index.html`, `styles.css`, `game.js`, and `README.md` to the repository root.
3. In Netlify, choose **Add new site** → **Import an existing project**.
4. Connect the GitHub repository.
5. Use these settings:
   - Build command: leave blank
   - Publish directory: `/` or leave default as the repository root
6. Deploy.

## Local testing

Open `index.html` directly in a browser, or run a simple local server from the folder:

```bash
python3 -m http.server 8080
```

Then visit `http://localhost:8080`.
