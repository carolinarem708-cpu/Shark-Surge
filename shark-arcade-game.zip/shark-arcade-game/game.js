(() => {
  "use strict";

  const gameArea = document.getElementById("gameArea");
  const playerEl = document.getElementById("player");
  const startScreen = document.getElementById("startScreen");
  const gameOverScreen = document.getElementById("gameOverScreen");
  const startButton = document.getElementById("startButton");
  const restartButton = document.getElementById("restartButton");
  const dashButton = document.getElementById("dashButton");
  const scoreEl = document.getElementById("score");
  const levelEl = document.getElementById("level");
  const heartsEl = document.getElementById("hearts");
  const finalScoreEl = document.getElementById("finalScore");
  const finalLevelEl = document.getElementById("finalLevel");
  const bestScoreEl = document.getElementById("bestScore");

  const abilityEls = {
    dash: document.getElementById("abilityDash"),
    magnet: document.getElementById("abilityMagnet"),
    armor: document.getElementById("abilityArmor"),
  };

  const clamp = (value, min, max) => Math.max(min, Math.min(max, value));
  const rand = (min, max) => Math.random() * (max - min) + min;

  const state = {
    running: false,
    over: false,
    lastTime: 0,
    width: 900,
    height: 520,
    score: 0,
    bestScore: Number(localStorage.getItem("sharkSurgeBest") || 0),
    level: 1,
    growth: 0,
    timeAlive: 0,
    spawnTimer: 0,
    spawnEvery: 980,
    hazardTimer: 0,
    combo: 0,
    comboTimer: 0,
    entities: [],
    pointer: { active: false, x: 0, y: 0 },
    keys: { up: false, down: false, left: false, right: false },
    player: {
      x: 110,
      y: 220,
      baseW: 112,
      baseH: 58,
      scale: 0.82,
      biteSize: 1,
      speed: 310,
      health: 3,
      maxHealth: 3,
      invulnerable: 0,
      dashCooldown: 0,
      dashTime: 0,
      facing: 1,
    },
  };

  function updateBounds() {
    const rect = gameArea.getBoundingClientRect();
    state.width = Math.max(320, rect.width);
    state.height = Math.max(260, rect.height);
  }

  function resetGame() {
    updateBounds();
    clearEntities();
    Object.assign(state, {
      running: true,
      over: false,
      lastTime: performance.now(),
      score: 0,
      level: 1,
      growth: 0,
      timeAlive: 0,
      spawnTimer: 0,
      spawnEvery: 980,
      hazardTimer: 1500,
      combo: 0,
      comboTimer: 0,
      entities: [],
    });

    Object.assign(state.player, {
      x: Math.min(110, state.width * 0.25),
      y: state.height * 0.46,
      scale: 0.82,
      biteSize: 1,
      speed: 310,
      health: 3,
      maxHealth: 3,
      invulnerable: 0,
      dashCooldown: 0,
      dashTime: 0,
      facing: 1,
    });

    startScreen.classList.remove("show");
    gameOverScreen.classList.remove("show");
    updateHud();
    setPlayerTransform();

    for (let i = 0; i < 5; i += 1) spawnFish(true);
    requestAnimationFrame(loop);
  }

  function clearEntities() {
    for (const entity of state.entities) entity.el.remove();
    state.entities = [];
    document.querySelectorAll(".chomp,.float-text").forEach((node) => node.remove());
  }

  function loop(now) {
    if (!state.running) return;
    const dt = Math.min(0.033, (now - state.lastTime) / 1000 || 0.016);
    state.lastTime = now;

    update(dt);
    render();

    if (state.running) requestAnimationFrame(loop);
  }

  function update(dt) {
    state.timeAlive += dt;
    state.spawnTimer -= dt * 1000;
    state.hazardTimer -= dt * 1000;
    if (state.comboTimer > 0) state.comboTimer -= dt;
    if (state.comboTimer <= 0) state.combo = 0;

    const p = state.player;
    p.invulnerable = Math.max(0, p.invulnerable - dt);
    p.dashCooldown = Math.max(0, p.dashCooldown - dt);
    p.dashTime = Math.max(0, p.dashTime - dt);

    const difficulty = 1 + state.timeAlive / 62 + state.level * 0.13;
    state.spawnEvery = clamp(1050 - state.timeAlive * 8 - state.level * 42, 360, 1050);

    if (state.spawnTimer <= 0) {
      spawnFish(false);
      if (Math.random() < 0.18 + state.level * 0.018) spawnFish(false);
      state.spawnTimer = state.spawnEvery * rand(0.72, 1.2);
    }

    if (state.level >= 2 && state.hazardTimer <= 0) {
      if (Math.random() < 0.72) spawnJelly();
      if (state.level >= 3 && Math.random() < 0.42) spawnPredator();
      state.hazardTimer = clamp(2500 - state.level * 170 - state.timeAlive * 8, 850, 2400);
    }

    movePlayer(dt);
    updateEntities(dt, difficulty);
    checkCollisions();
    updateHud();
  }

  function movePlayer(dt) {
    const p = state.player;
    let dx = 0;
    let dy = 0;

    if (state.keys.up) dy -= 1;
    if (state.keys.down) dy += 1;
    if (state.keys.left) dx -= 1;
    if (state.keys.right) dx += 1;

    if (state.pointer.active) {
      const centerX = p.x + (p.baseW * p.scale) / 2;
      const centerY = p.y + (p.baseH * p.scale) / 2;
      const tx = state.pointer.x - centerX;
      const ty = state.pointer.y - centerY;
      const distance = Math.hypot(tx, ty);
      if (distance > 12) {
        dx += tx / distance;
        dy += ty / distance;
      }
    }

    const len = Math.hypot(dx, dy) || 1;
    dx /= len;
    dy /= len;

    const dashBoost = p.dashTime > 0 ? 2.45 : 1;
    const sizeDrag = 1 - Math.min(0.22, (p.scale - 0.82) * 0.09);
    const speed = p.speed * dashBoost * sizeDrag;
    p.x += dx * speed * dt;
    p.y += dy * speed * dt;

    if (dx > 0.05) p.facing = 1;
    if (dx < -0.05) p.facing = -1;

    const w = p.baseW * p.scale;
    const h = p.baseH * p.scale;
    p.x = clamp(p.x, -w * 0.1, state.width - w * 0.88);
    p.y = clamp(p.y, 4, state.height - h - 30);
  }

  function updateEntities(dt, difficulty) {
    const magnetRadius = state.level >= 3 ? 145 + state.player.scale * 20 : 0;
    const pCenter = getPlayerCenter();

    for (let i = state.entities.length - 1; i >= 0; i -= 1) {
      const e = state.entities[i];
      e.age += dt;
      e.x += e.vx * dt * difficulty;
      e.y += Math.sin(e.age * e.wave + e.phase) * e.wobble * dt;

      if (magnetRadius && e.kind === "fish" && e.edibleSize <= state.player.biteSize + 0.18) {
        const cx = e.x + e.w / 2;
        const cy = e.y + e.h / 2;
        const toPlayerX = pCenter.x - cx;
        const toPlayerY = pCenter.y - cy;
        const distance = Math.hypot(toPlayerX, toPlayerY);
        if (distance < magnetRadius && distance > 1) {
          const pull = (1 - distance / magnetRadius) * 125;
          e.x += (toPlayerX / distance) * pull * dt;
          e.y += (toPlayerY / distance) * pull * dt;
        }
      }

      if (e.y < 4 || e.y > state.height - e.h - 36) e.vy *= -1;
      e.y = clamp(e.y, 6, state.height - e.h - 34);

      if (e.x < -160 || e.x > state.width + 180) {
        removeEntity(i);
      }
    }
  }

  function checkCollisions() {
    const p = state.player;
    const pBox = getPlayerBox();

    for (let i = state.entities.length - 1; i >= 0; i -= 1) {
      const e = state.entities[i];
      const eBox = { x: e.x, y: e.y, w: e.w, h: e.h };
      if (!boxesOverlap(pBox, eBox)) continue;

      if (e.kind === "fish") {
        if (e.edibleSize <= p.biteSize + 0.12 || p.dashTime > 0 && state.level >= 5) {
          eatEntity(e, i);
        } else {
          takeDamage(1, e.x, e.y, "Too big!");
          e.vx *= -1.2;
          e.x += 50;
        }
      } else if (e.kind === "hazard") {
        if (p.dashTime > 0 && state.level >= 4) {
          eatEntity(e, i, true);
        } else {
          takeDamage(e.damage, e.x, e.y, "Zap!");
          removeEntity(i);
        }
      } else if (e.kind === "predator") {
        if (e.edibleSize <= p.biteSize + 0.05 || p.dashTime > 0 && state.level >= 5) {
          eatEntity(e, i);
        } else {
          takeDamage(1, e.x, e.y, "Ouch!");
          e.vx *= -1;
          e.x += 65;
        }
      }
    }
  }

  function boxesOverlap(a, b) {
    return a.x < b.x + b.w && a.x + a.w > b.x && a.y < b.y + b.h && a.y + a.h > b.y;
  }

  function getPlayerBox() {
    const p = state.player;
    const w = p.baseW * p.scale * 0.78;
    const h = p.baseH * p.scale * 0.7;
    return {
      x: p.x + p.baseW * p.scale * 0.12,
      y: p.y + p.baseH * p.scale * 0.15,
      w,
      h,
    };
  }

  function getPlayerCenter() {
    const p = state.player;
    return {
      x: p.x + (p.baseW * p.scale) / 2,
      y: p.y + (p.baseH * p.scale) / 2,
    };
  }

  function eatEntity(entity, index, hazardSnack = false) {
    const p = state.player;
    state.combo = state.comboTimer > 0 ? state.combo + 1 : 1;
    state.comboTimer = 1.25;
    const comboBonus = Math.min(4, Math.floor(state.combo / 4));
    const points = entity.points + comboBonus * 5;

    state.score += points;
    state.growth += entity.growth;
    p.biteSize += entity.growth * 0.075;
    p.scale = clamp(p.scale + entity.growth * 0.015, 0.82, 2.05);

    if (entity.variant === "gold") {
      p.dashCooldown = Math.max(0, p.dashCooldown - 2.2);
      if (p.health < p.maxHealth) p.health += 1;
    }

    if (hazardSnack) {
      state.score += 18;
      p.invulnerable = Math.max(p.invulnerable, 0.45);
    }

    chompEffect(entity.x + entity.w / 2, entity.y + entity.h / 2);
    floatingText(`+${points}`, entity.x, entity.y, entity.variant === "gold" ? "gold" : "good");
    removeEntity(index);
    maybeLevelUp();
  }

  function maybeLevelUp() {
    const oldLevel = state.level;
    state.level = clamp(1 + Math.floor(state.growth / 7), 1, 7);

    if (state.level > oldLevel) {
      floatingText(`LEVEL ${state.level}`, state.player.x + 18, state.player.y - 10, "gold");
      state.player.invulnerable = 1.1;
      if (state.level >= 4 && state.player.maxHealth < 4) {
        state.player.maxHealth = 4;
        state.player.health = Math.min(state.player.maxHealth, state.player.health + 1);
      }
      if (state.level >= 6 && state.player.maxHealth < 5) {
        state.player.maxHealth = 5;
        state.player.health = Math.min(state.player.maxHealth, state.player.health + 1);
      }
    }
  }

  function takeDamage(amount, x, y, label) {
    const p = state.player;
    if (p.invulnerable > 0) return;

    const armorReduction = state.level >= 4 && Math.random() < 0.35 ? 1 : 0;
    const net = Math.max(0, amount - armorReduction);

    if (net === 0) {
      p.invulnerable = 0.55;
      floatingText("Blocked!", x, y, "good");
      return;
    }

    p.health -= net;
    p.invulnerable = 1.15;
    state.combo = 0;
    state.comboTimer = 0;
    floatingText(label, x, y, "danger");
    gameArea.animate([
      { transform: "translateX(0)" },
      { transform: "translateX(-5px)" },
      { transform: "translateX(5px)" },
      { transform: "translateX(0)" },
    ], { duration: 180, easing: "ease-out" });

    if (p.health <= 0) endGame();
  }

  function endGame() {
    state.running = false;
    state.over = true;
    state.bestScore = Math.max(state.bestScore, state.score);
    localStorage.setItem("sharkSurgeBest", String(state.bestScore));
    finalScoreEl.textContent = Math.round(state.score).toLocaleString();
    finalLevelEl.textContent = state.level;
    bestScoreEl.textContent = Math.round(state.bestScore).toLocaleString();
    gameOverScreen.classList.add("show");
  }

  function spawnFish(initial) {
    const roll = Math.random();
    let type;
    if (roll < 0.58) type = "small";
    else if (roll < 0.82) type = "silver";
    else if (roll < 0.94) type = "gold";
    else type = "big";

    const data = {
      small: { variant: "orange", className: "fish", w: 52, h: 30, scale: rand(0.82, 1.06), edibleSize: 0.7, points: 10, growth: 0.7, speed: rand(90, 155) },
      silver: { variant: "silver", className: "fish silver", w: 58, h: 34, scale: rand(1.05, 1.28), edibleSize: 1.15, points: 22, growth: 1.05, speed: rand(110, 180) },
      gold: { variant: "gold", className: "fish gold", w: 50, h: 29, scale: rand(0.9, 1.08), edibleSize: 0.88, points: 45, growth: 1.35, speed: rand(135, 210) },
      big: { variant: "big", className: "fish big", w: 66, h: 38, scale: rand(1.35, 1.8), edibleSize: rand(1.65, 2.5), points: 36, growth: 1.55, speed: rand(88, 145) },
    }[type];

    const el = document.createElement("div");
    el.className = `entity ${data.className}`;
    el.innerHTML = "<div class='fish-tail'></div><div class='fish-body'></div><div class='fish-fin'></div><div class='fish-eye'></div>";
    gameArea.appendChild(el);

    const fromRight = initial ? Math.random() > 0.5 : true;
    const scale = data.scale;
    const entity = {
      id: cryptoRandomId(),
      kind: "fish",
      variant: data.variant,
      el,
      x: fromRight ? rand(state.width * 0.45, state.width + 120) : rand(60, state.width * 0.9),
      y: rand(16, state.height - 86),
      w: data.w * scale,
      h: data.h * scale,
      scale,
      vx: -data.speed,
      vy: 0,
      edibleSize: data.edibleSize,
      points: data.points,
      growth: data.growth,
      wave: rand(3.2, 7.8),
      wobble: rand(16, 42),
      phase: rand(0, Math.PI * 2),
      age: rand(0, 1.5),
    };
    state.entities.push(entity);
    renderEntity(entity);
  }

  function spawnJelly() {
    const scale = rand(0.9, 1.22 + state.level * 0.03);
    const el = document.createElement("div");
    el.className = "entity jelly";
    el.innerHTML = "<div class='jelly-dome'></div><div class='jelly-tentacles'></div>";
    gameArea.appendChild(el);

    const entity = {
      id: cryptoRandomId(),
      kind: "hazard",
      variant: "jelly",
      el,
      x: rand(state.width + 40, state.width + 160),
      y: rand(10, state.height - 100),
      w: 45 * scale,
      h: 56 * scale,
      scale,
      vx: -rand(80, 138 + state.level * 8),
      vy: 0,
      edibleSize: 99,
      points: 14,
      growth: 0.35,
      damage: 1,
      wave: rand(2, 4),
      wobble: rand(24, 44),
      phase: rand(0, Math.PI * 2),
      age: 0,
    };
    state.entities.push(entity);
    renderEntity(entity);
  }

  function spawnPredator() {
    const scale = rand(1.55, 2.05 + state.level * 0.05);
    const el = document.createElement("div");
    el.className = "entity fish big";
    el.innerHTML = "<div class='fish-tail'></div><div class='fish-body'></div><div class='fish-fin'></div><div class='fish-eye'></div>";
    gameArea.appendChild(el);

    const entity = {
      id: cryptoRandomId(),
      kind: "predator",
      variant: "predator",
      el,
      x: rand(state.width + 60, state.width + 220),
      y: rand(18, state.height - 92),
      w: 66 * scale,
      h: 38 * scale,
      scale,
      vx: -rand(120, 190 + state.level * 10),
      vy: 0,
      edibleSize: rand(2.15, 3.1),
      points: 62,
      growth: 2.1,
      damage: 1,
      wave: rand(3, 6),
      wobble: rand(10, 24),
      phase: rand(0, Math.PI * 2),
      age: 0,
    };
    state.entities.push(entity);
    renderEntity(entity);
  }

  function removeEntity(index) {
    const [entity] = state.entities.splice(index, 1);
    if (entity) entity.el.remove();
  }

  function render() {
    setPlayerTransform();
    for (const entity of state.entities) renderEntity(entity);
  }

  function setPlayerTransform() {
    const p = state.player;
    playerEl.style.transform = `translate3d(${p.x}px, ${p.y}px, 0) scale(${p.facing * p.scale}, ${p.scale})`;
    playerEl.style.opacity = p.invulnerable > 0 ? (Math.floor(p.invulnerable * 14) % 2 ? "0.58" : "1") : "1";
    playerEl.classList.toggle("dashing", p.dashTime > 0);
  }

  function renderEntity(entity) {
    const facingScale = entity.vx <= 0 ? -entity.scale : entity.scale;
    entity.el.style.transform = `translate3d(${entity.x}px, ${entity.y}px, 0) scale(${facingScale}, ${entity.scale})`;
  }

  function updateHud() {
    scoreEl.textContent = Math.round(state.score).toLocaleString();
    levelEl.textContent = state.level;
    heartsEl.textContent = "♥ ".repeat(state.player.health).trim() + (state.player.health < state.player.maxHealth ? " ·".repeat(state.player.maxHealth - state.player.health) : "");

    abilityEls.dash.classList.toggle("active", state.level >= 2);
    abilityEls.magnet.classList.toggle("active", state.level >= 3);
    abilityEls.armor.classList.toggle("active", state.level >= 4);
    abilityEls.dash.classList.toggle("cooling", state.level >= 2 && state.player.dashCooldown > 0);

    dashButton.classList.toggle("locked", state.level < 2);
    dashButton.classList.toggle("cooldown", state.level >= 2 && state.player.dashCooldown > 0);
    if (state.level < 2) dashButton.textContent = "L2";
    else if (state.player.dashCooldown > 0) dashButton.textContent = Math.ceil(state.player.dashCooldown).toString();
    else dashButton.textContent = "Dash";
  }

  function chompEffect(x, y) {
    const effect = document.createElement("div");
    effect.className = "chomp";
    effect.style.left = `${x - 21}px`;
    effect.style.top = `${y - 21}px`;
    gameArea.appendChild(effect);
    setTimeout(() => effect.remove(), 380);
  }

  function floatingText(text, x, y, tone = "good") {
    const node = document.createElement("div");
    node.className = "float-text";
    node.textContent = text;
    node.style.left = `${x}px`;
    node.style.top = `${y}px`;
    node.style.color = tone === "danger" ? "var(--danger)" : tone === "gold" ? "var(--gold)" : "var(--good)";
    gameArea.appendChild(node);
    setTimeout(() => node.remove(), 780);
  }

  function tryDash() {
    if (!state.running || state.level < 2) return;
    const p = state.player;
    if (p.dashCooldown > 0) return;
    p.dashTime = state.level >= 5 ? 0.34 : 0.25;
    p.dashCooldown = state.level >= 5 ? 2.7 : 3.6;
  }

  function cryptoRandomId() {
    if (window.crypto && crypto.getRandomValues) {
      const array = new Uint32Array(1);
      crypto.getRandomValues(array);
      return array[0].toString(36);
    }
    return Math.random().toString(36).slice(2);
  }

  function setKey(code, active) {
    if (["ArrowUp", "KeyW"].includes(code)) state.keys.up = active;
    if (["ArrowDown", "KeyS"].includes(code)) state.keys.down = active;
    if (["ArrowLeft", "KeyA"].includes(code)) state.keys.left = active;
    if (["ArrowRight", "KeyD"].includes(code)) state.keys.right = active;
  }

  function gamePointFromEvent(event) {
    const rect = gameArea.getBoundingClientRect();
    return {
      x: event.clientX - rect.left,
      y: event.clientY - rect.top,
    };
  }

  startButton.addEventListener("click", resetGame);
  restartButton.addEventListener("click", resetGame);
  dashButton.addEventListener("click", tryDash);

  window.addEventListener("resize", updateBounds);
  window.addEventListener("orientationchange", () => setTimeout(updateBounds, 120));

  window.addEventListener("keydown", (event) => {
    if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", "Space", "KeyW", "KeyA", "KeyS", "KeyD"].includes(event.code)) {
      event.preventDefault();
    }
    if (event.code === "Space") tryDash();
    else setKey(event.code, true);
  }, { passive: false });

  window.addEventListener("keyup", (event) => setKey(event.code, false));

  gameArea.addEventListener("pointerdown", (event) => {
    if (!state.running) return;
    const point = gamePointFromEvent(event);
    state.pointer.active = true;
    state.pointer.x = point.x;
    state.pointer.y = point.y;
    gameArea.setPointerCapture?.(event.pointerId);
  });

  gameArea.addEventListener("pointermove", (event) => {
    if (!state.pointer.active) return;
    const point = gamePointFromEvent(event);
    state.pointer.x = point.x;
    state.pointer.y = point.y;
  });

  gameArea.addEventListener("pointerup", () => {
    state.pointer.active = false;
  });

  gameArea.addEventListener("pointercancel", () => {
    state.pointer.active = false;
  });

  document.querySelectorAll(".control-btn").forEach((button) => {
    const dir = button.dataset.dir;
    const set = (active) => {
      state.keys[dir] = active;
    };
    button.addEventListener("pointerdown", (event) => {
      event.preventDefault();
      set(true);
      button.setPointerCapture?.(event.pointerId);
    });
    button.addEventListener("pointerup", () => set(false));
    button.addEventListener("pointercancel", () => set(false));
    button.addEventListener("pointerleave", () => set(false));
  });

  updateBounds();
  updateHud();
  setPlayerTransform();
})();
